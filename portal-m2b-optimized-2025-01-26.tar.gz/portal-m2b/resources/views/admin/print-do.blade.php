<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <title>Surat Jalan - {{ $shipment->awb_number }}</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        @media print {
            @page { margin: 0; size: A4; }
            body { margin: 0; -webkit-print-color-adjust: exact; }
            .no-print { display: none !important; }
            .page-break { page-break-after: always; }
        }
        body { font-family: 'Arial', sans-serif; }
    </style>
</head>
<body class="bg-gray-200 print:bg-white">

@php
    $containers = [];
    if (request()->has('containers')) {
        $containers = json_decode(urldecode(request('containers')), true) ?: [];
    }
    if (empty($containers)) {
        $containers = [['no_container' => '', 'no_polisi' => '', 'nama_supir' => '', 'no_seal' => '']];
    }
@endphp

@foreach($containers as $index => $container)
<div class="max-w-[21cm] mx-auto bg-white p-10 shadow-lg print:shadow-none min-h-[29.7cm] relative {{ !$loop->last ? 'page-break' : '' }} print:p-8">
    {{-- KOP SURAT --}}
    <div class="flex items-center gap-4 border-b-4 border-double border-black pb-4 mb-6">
        <img src="{{ asset('images/m2b-logo.png') }}" class="h-20 w-auto">
        <div class="flex-1">
            <h1 class="text-2xl font-black text-blue-900 tracking-tight">PT. MORA MULTI BERKAH</h1>
            <p class="font-bold text-gray-600">Logistic Solution & Freight Forwarding</p>
            <div class="text-xs mt-1">
                <p>Jl. Kapt. Sumarsono Komp. Graha Metropolitan Blok G No. 14</p>
                <p>Medan, Sumatera Utara - Indonesia</p>
                <p>Telp: (061) 440-200-12 | Email: info@m2b.co.id</p>
            </div>
        </div>
        <div class="text-right border border-black p-2 min-w-[150px]">
            <p class="text-[10px] uppercase font-bold bg-gray-200 mb-1">TANGGAL CETAK</p>
            <p class="font-mono font-bold text-lg">{{ now()->format('d M Y') }}</p>
        </div>
    </div>

    <div class="text-center mb-8">
        <h2 class="text-2xl font-black underline decoration-2 underline-offset-4 uppercase">
            @if(strtolower($shipment->service_type) == 'export') SURAT PENGANTAR BARANG (EXPORT)
            @elseif(strtolower($shipment->service_type) == 'domestic') SURAT JALAN (DOMESTIC)
            @else SURAT JALAN / DELIVERY ORDER @endif
        </h2>
        <p class="font-bold text-lg mt-1">NO: {{ $shipment->awb_number }}{{ count($containers) > 1 ? ' - ' . ($index + 1) . '/' . count($containers) : '' }}</p>
    </div>

    <div class="grid grid-cols-2 gap-0 border border-black mb-6">
        {{-- KOLOM PENGIRIM --}}
        <div class="p-4 border-r border-black">
            <p class="text-xs font-bold bg-black text-white inline-block px-2 py-0.5 mb-2">DARI / PENGIRIM (SHIPPER)</p>
            <p class="font-bold text-lg uppercase">PT. MORA MULTI BERKAH</p>
            <div class="text-sm mt-1 uppercase">
                <span class="text-gray-500 text-xs block mb-0.5">Lokasi Muat / Origin:</span>
                {{ $shipment->origin }}
            </div>
        </div>

        {{-- KOLOM PENERIMA --}}
        <div class="p-4">
            <p class="text-xs font-bold bg-black text-white inline-block px-2 py-0.5 mb-2">KEPADA / PENERIMA (CONSIGNEE)</p>
            @if(strtolower($shipment->service_type) == 'export')
                <p class="font-bold text-lg uppercase">DEPO PELAYARAN / PORT</p>
                <div class="text-sm mt-1 uppercase">
                    <span class="text-gray-500 text-xs block mb-0.5">Tujuan / Destination:</span>
                    {{ $shipment->destination }}
                </div>
            @else
                <p class="font-bold text-lg uppercase">{{ $shipment->customer->company_name }}</p>
                <div class="text-sm mt-1 uppercase">
                    <span class="text-gray-500 text-xs block mb-0.5">Alamat Bongkar:</span>
                    {{ $shipment->destination }}
                </div>
            @endif
        </div>
    </div>

    <table class="w-full border-collapse border border-black mb-8">
        <thead class="bg-gray-100">
            <tr>
                <th class="border border-black p-2 w-10">NO</th>
                <th class="border border-black p-2 text-left">URAIAN BARANG / KONTAINER</th>
                <th class="border border-black p-2 w-24">QTY</th>
                <th class="border border-black p-2 w-24">UNIT</th>
                <th class="border border-black p-2 w-32">KET</th>
            </tr>
        </thead>
        <tbody>
            <tr class="h-40">
                <td class="border border-black p-2 text-center align-top">{{ $index + 1 }}</td>
                <td class="border border-black p-2 align-top">
                    <p class="font-bold text-lg uppercase">{{ $shipment->container_mode }}</p>
                    <p class="mb-2">{{ $shipment->container_info }}</p>
                    
                    {{-- Data Container dari Input --}}
                    <div class="border-t border-dashed border-gray-400 pt-3 mt-3 space-y-2">
                        <div class="grid grid-cols-2 gap-x-4 text-sm">
                            <p><span class="text-gray-500">No. Container:</span> <strong>{{ $container['no_container'] ?: '..............................' }}</strong></p>
                            <p><span class="text-gray-500">No. Polisi:</span> <strong>{{ $container['no_polisi'] ?: '..............................' }}</strong></p>
                        </div>
                        <div class="grid grid-cols-2 gap-x-4 text-sm">
                            <p><span class="text-gray-500">Nama Supir:</span> <strong>{{ $container['nama_supir'] ?: '..............................' }}</strong></p>
                            <p><span class="text-gray-500">No. Segel/Seal:</span> <strong>{{ $container['no_seal'] ?: '..............................' }}</strong></p>
                        </div>
                    </div>
                </td>
                <td class="border border-black p-2 text-center align-top font-bold text-lg">{{ $shipment->pieces }}</td>
                <td class="border border-black p-2 text-center align-top uppercase">{{ $shipment->package_type }}</td>
                <td class="border border-black p-2 text-center align-top text-xs">
                    {{ number_format($shipment->weight) }} Kg
                    <br><br>
                    <span class="uppercase font-bold">{{ $shipment->service_type }}</span>
                </td>
            </tr>
        </tbody>
    </table>

    <div class="grid grid-cols-4 gap-4 text-center mt-12">
        <div><p class="text-xs font-bold mb-16">ADMIN / PENGIRIM</p><p class="border-t border-black mx-2 pt-1 font-bold">( PT. M2B )</p></div>
        <div><p class="text-xs font-bold mb-16">SUPIR / CARRIER</p><p class="border-t border-black mx-2 pt-1">( {{ $container['nama_supir'] ?: '.................' }} )</p></div>
        <div><p class="text-xs font-bold mb-16">SECURITY GUDANG</p><p class="border-t border-black mx-2 pt-1">( ................. )</p></div>
        <div><p class="text-xs font-bold mb-16">PENERIMA BARANG</p><p class="border-t border-black mx-2 pt-1">( ................. )</p></div>
    </div>

    {{-- Footer Info --}}
    <div class="absolute bottom-8 left-10 right-10 text-center border-t border-gray-300 pt-2">
        <p class="text-[10px] text-gray-500 italic">Barang telah diterima dalam keadaan baik dan cukup. Segala kerusakan setelah barang diterima bukan tanggung jawab pengirim.</p>
    </div>
</div>

@if(!$loop->last)
<div class="h-8 print:hidden"></div>
@endif

@endforeach

<div class="fixed bottom-8 right-8 flex flex-col gap-3 no-print">
    <button onclick="window.print()" class="bg-blue-900 text-white p-4 rounded-full shadow-xl hover:scale-110 transition">
        <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z"></path></svg>
    </button>
</div>

</body>
</html>
