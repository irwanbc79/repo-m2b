<div class="space-y-6">
    {{-- 1. FIX JUDUL HALAMAN --}}
    @section('header', 'Invoicing dan Tagihan')
    
    {{-- ALERT MESSAGES --}}
    @if (session()->has('message'))
        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4 shadow-sm flex items-center gap-2 animate-fade-in">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path></svg>
            {{ session('message') }}
        </div>
    @endif
    @if (session()->has('error'))
        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4 shadow-sm flex items-center gap-2 animate-fade-in">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
            {{ session('error') }}
        </div>
    @endif

    {{-- Stats Cards --}}
    <div class="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4 mb-6">
        <div class="bg-white rounded-xl p-4 shadow-sm border border-gray-100 text-center">
            <p class="text-2xl font-black text-gray-800">{{ $stats["total"] ?? 0 }}</p>
            <p class="text-xs text-gray-500">Total Invoice</p>
        </div>
        <div class="bg-red-50 rounded-xl p-4 shadow-sm border border-red-100 text-center">
            <p class="text-2xl font-black text-red-600">{{ $stats["unpaid"] ?? 0 }}</p>
            <p class="text-xs text-gray-500">Unpaid</p>
        </div>
        <div class="bg-green-50 rounded-xl p-4 shadow-sm border border-green-100 text-center">
            <p class="text-2xl font-black text-green-600">{{ $stats["paid"] ?? 0 }}</p>
            <p class="text-xs text-gray-500">Paid</p>
        </div>
        <div class="bg-orange-50 rounded-xl p-4 shadow-sm border border-orange-100 text-center">
            <p class="text-2xl font-black text-orange-600">{{ $stats["overdue"] ?? 0 }}</p>
            <p class="text-xs text-gray-500">Overdue</p>
        </div>
        <div class="bg-yellow-50 rounded-xl p-4 shadow-sm border border-yellow-100 text-center">
            <p class="text-lg font-black text-yellow-700">{{ number_format($stats["total_receivable"] ?? 0, 0, ",", ".") }}</p>
            <p class="text-xs text-gray-500">Receivable</p>
        </div>
        <div class="bg-emerald-50 rounded-xl p-4 shadow-sm border border-emerald-100 text-center">
            <p class="text-lg font-black text-emerald-600">{{ number_format($stats["total_collected"] ?? 0, 0, ",", ".") }}</p>
            <p class="text-xs text-gray-500">Collected</p>
        </div>
        <div class="bg-purple-50 rounded-xl p-4 shadow-sm border border-purple-100 text-center relative">
            @if(($stats["faktur_pajak_requests"] ?? 0) > 0)
            <span class="absolute -top-2 -right-2 bg-red-500 text-white text-xs font-bold px-2 py-1 rounded-full animate-pulse">!</span>
            @endif
            <p class="text-2xl font-black text-purple-600">{{ $stats["faktur_pajak_requests"] ?? 0 }}</p>
            <p class="text-xs text-gray-500">Request F.Pajak</p>
        </div>
    </div>


    {{-- LIST INVOICE (TABEL UTAMA) --}}
    <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
        <div class="p-6 border-b border-gray-100 bg-gray-50 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
            <div class="flex flex-wrap items-center gap-3">
                {{-- Search --}}
                <div class="relative">
                    <input wire:model.live.debounce.300ms="search" type="text" placeholder="Cari No Invoice / Customer..." class="w-64 pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-600 focus:ring-1 focus:ring-blue-600 transition shadow-sm">
                    <svg class="w-5 h-5 text-gray-400 absolute left-3 top-2.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path></svg>
                </div>
                
                {{-- Filter Status --}}
                <select wire:model.live="filterStatus" class="border-gray-300 rounded-lg text-sm py-2 px-3 focus:ring-2 focus:ring-blue-500">
                    <option value="">Semua Status</option>
                    <option value="unpaid">Unpaid</option>
                    <option value="paid">Paid</option>
                    <option value="overdue">Overdue</option>
                </select>
                
                {{-- Filter Type --}}
                <select wire:model.live="filterType" class="border-gray-300 rounded-lg text-sm py-2 px-3 focus:ring-2 focus:ring-blue-500">
                    <option value="">Semua Tipe</option>
                    <option value="commercial">Commercial</option>
                    <option value="proforma">Proforma</option>
                </select>
            </div>
            
            <button wire:click="create" class="bg-blue-900 hover:bg-blue-800 text-white px-4 py-2 rounded-lg transition flex items-center shadow-md font-bold justify-center hover:shadow-lg">
                <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"></path></svg>
                Buat Invoice Baru
            </button>
        </div>

        <div class="overflow-x-auto">
            <table class="w-full text-sm text-left">
                <thead class="bg-gray-100 text-gray-600 font-bold uppercase text-xs border-b">
                    <tr>
                        <th class="px-6 py-4">Invoice No / Tipe</th>
                        <th class="px-6 py-4">Customer</th>
                        <th class="px-6 py-4">Jatuh Tempo</th>
                        <th class="px-6 py-4">Total</th>
                        <th class="px-6 py-4">Status</th>
                        <th class="px-6 py-4">Related Invoice</th>
                        <th class="px-6 py-4 text-center">Klaim</th>
                        <th class="px-6 py-4 text-center">Faktur Pajak</th>
                        <th class="px-6 py-4 text-center">Aksi</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-100">
                    @forelse($invoices as $inv)
                    <tr class="hover:bg-gray-50 transition">
                        <td class="px-6 py-4">
                            <span class="block font-bold text-blue-900">{{ $inv->invoice_number }}</span>
                            <span class="text-[10px] {{ $inv->type == 'Proforma' ? 'bg-orange-100 text-orange-700' : 'bg-blue-50 text-blue-700' }} px-2 py-0.5 rounded font-bold uppercase">{{ $inv->type }}</span>
                        </td>
                        <td class="px-6 py-4">
                            <div class="font-bold text-gray-800">
                                {{ $inv->customer->company_name ?? ($inv->shipment->customer->company_name ?? '-') }}
                            </div>
                            @if($inv->shipment)
                                <div class="text-xs text-gray-500">Ref: {{ $inv->shipment->awb_number }}</div>
                            @else
                                <div class="text-xs text-orange-500 italic">No Shipment (DP)</div>
                            @endif
                        </td>
                        <td class="px-6 py-4 text-red-500 font-bold text-xs">{{ $inv->due_date ? date('d M Y', strtotime($inv->due_date)) : '-' }}</td>
                        <td class="px-6 py-4 font-mono font-bold">
                            @if($inv->status == 'partial')
                                <span class="text-orange-600">Rp {{ number_format($inv->grand_total - ($inv->total_paid ?? 0), 0, ',', '.') }}</span>
                                <div class="text-[10px] text-gray-400 font-normal">dari Rp {{ number_format($inv->grand_total, 0, ',', '.') }}</div>
                            @else
                                Rp {{ number_format($inv->grand_total, 0, ',', '.') }}
                            @endif
                        </td>
                        <td class="px-6 py-4">
                            <span class="px-2.5 py-1 rounded-full text-xs font-bold uppercase {{ $inv->status == 'paid' ? 'bg-green-100 text-green-700' : ($inv->status == 'partial' ? 'bg-yellow-100 text-yellow-700' : 'bg-red-100 text-red-700') }}">
                                {{ $inv->status }}
                            </span>
                        </td>
                        <td class="px-6 py-4">
                            @if($inv->shipment_id)
                                @php
                                    $relatedInv = \App\Models\Invoice::where('shipment_id', $inv->shipment_id)
                                        ->where('id', '!=', $inv->id)
                                        ->first();
                                @endphp
                                @if($relatedInv)
                                    <span class="text-{{ $relatedInv->type === 'Commercial' ? 'blue' : 'purple' }}-600 text-xs font-bold">
                                        {{ $relatedInv->type === 'Commercial' ? '→' : '←' }} {{ $relatedInv->invoice_number }}
                                    </span>
                                @else
                                    <span class="text-gray-400 text-xs">-</span>
                                @endif
                            @else
                                <span class="text-gray-400 text-xs">-</span>
                            @endif
                        </td>
                        <td class="px-6 py-4 text-center" x-data="{ showUpload: false }">
                            @if($inv->status == 'paid')
                                <span class="px-2 py-1 text-xs font-medium bg-green-100 text-green-800 rounded-full">✓ PAID</span>
                            @elseif($inv->status == 'partial' && $inv->payment_claimed)
                                <span class="px-2 py-1 text-xs font-medium bg-yellow-100 text-yellow-800 rounded-full">⏳ PARTIAL</span>
                            @elseif($inv->payment_claimed)
                                <span class="px-2 py-1 text-xs font-medium bg-orange-100 text-orange-800 rounded-full">📎 CLAIMED</span>
                                @if($inv->claim_proof_path || $inv->payment_proof)
                                <button @click="$dispatch('preview-proof', { url: '{{ Storage::url($inv->claim_proof_path ?: $inv->payment_proof) }}', invoice: '{{ $inv->invoice_number }}' })" class="ml-1 text-blue-500 hover:text-blue-700">👁</button>
                                @endif
                            @else
                                <div class="relative inline-block">
                                    <button @click="showUpload = !showUpload" class="px-2 py-1 text-xs bg-gray-100 hover:bg-yellow-100 rounded-full">📤 Upload</button>
                                    <div x-show="showUpload" x-cloak @click.away="showUpload = false" class="absolute z-50 right-0 mt-2 w-72 bg-white rounded-lg shadow-xl border p-4">
                                        <div class="font-medium text-gray-700 mb-2">📤 Upload Bukti Klaim</div>
                                        <p class="text-xs text-gray-500 mb-3">{{ $inv->invoice_number }}</p>
                                        <form wire:submit.prevent="submitClaimDirect({{ $inv->id }})">
                                            <input type="file" wire:model="claimProofFile" accept="image/*,.pdf" class="w-full text-xs border rounded p-1.5 mb-2">
                                            @error('claimProofFile') <span class="text-red-500 text-xs">{{ $message }}</span> @enderror
                                            <div wire:loading wire:target="claimProofFile" class="text-xs text-blue-500">Uploading...</div>
                                            <textarea wire:model="claimNotes" rows="2" placeholder="Catatan (opsional)" class="w-full text-xs border rounded p-1.5 mb-2"></textarea>
                                            <div class="flex justify-end gap-2">
                                                <button type="button" @click="showUpload = false" class="px-3 py-1 text-xs text-gray-600">Batal</button>
                                                <button type="submit" class="px-3 py-1 text-xs bg-yellow-500 text-white rounded">Submit</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            @endif
                        </td>
                        <!-- Kolom Faktur Pajak -->
                        <td class="px-6 py-4 text-center">
                            @if($inv->status === 'paid')
                                @if($inv->faktur_pajak_path)
                                    <div class="flex items-center justify-center gap-1">
                                        <span class="text-xs text-green-600 font-medium">{{ $inv->faktur_pajak_number }}</span>
                                        <button wire:click="openFilePreview('{{ $inv->faktur_pajak_path }}')" class="text-blue-500 hover:text-blue-700" title="View">
                                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/></svg>
                                        </button>
                                        <button wire:click="openFakturPajakModal({{ $inv->id }})" class="text-yellow-500 hover:text-yellow-700" title="Edit">
                                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/></svg>
                                        </button>
                                        <button wire:click="deleteFakturPajak({{ $inv->id }})" wire:confirm="Yakin hapus faktur pajak ini?" class="text-red-500 hover:text-red-700" title="Hapus">
                                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>
                                        </button>
                                    </div>
                                @elseif($inv->faktur_pajak_requested)
                                    <button wire:click="openFakturPajakModal({{ $inv->id }})" class="text-xs bg-red-500 text-white hover:bg-red-600 px-2 py-1 rounded-full flex items-center justify-center gap-1 animate-pulse font-bold shadow" title="Customer Request!">
                                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12"/></svg>
                                        📋 Request!
                                    </button>
                                @else
                                    <button wire:click="openFakturPajakModal({{ $inv->id }})" class="text-xs text-gray-400 hover:text-orange-500 flex items-center justify-center gap-1">
                                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12"/></svg>
                                        Upload
                                    </button>
                                @endif
                            @else
                                <span class="text-xs text-gray-400">-</span>
                            @endif
                        </td>
                        <td class="px-6 py-4 text-center">
                            <div class="flex justify-center gap-2">
                                <div wire:ignore x-data="{ open: false }" class="relative inline-block">
                                    <button @click="open = !open" type="button" class="p-1.5 text-gray-500 border rounded hover:bg-gray-100" title="Print PDF">
                                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z"></path></svg>
                                    </button>
                                    <div x-show="open" @click.away="open = false" x-cloak class="absolute right-0 mt-1 w-56 bg-white border rounded-xl shadow-xl z-50 py-2">
                                        <a href="{{ route('admin.invoices.print', $inv->id) }}?signature=full&signer=1" target="_blank" class="block px-4 py-2 text-sm text-gray-700 hover:bg-green-50"><span class="font-bold">✓ Sign + Stamp</span><br><span class="text-xs text-gray-500">Nurul Asyikin</span></a>
                                        <a href="{{ route('admin.invoices.print', $inv->id) }}?signature=blank&signer=1" target="_blank" class="block px-4 py-2 text-sm text-gray-700 hover:bg-blue-50"><span class="font-bold">☐ Kosong</span><br><span class="text-xs text-gray-500">Untuk Materai Fisik</span></a>
                                    </div>
                                </div>
                                <button wire:click="openSendModal({{ $inv->id }})" class="p-1.5 text-blue-500 border border-blue-200 rounded hover:bg-blue-50" title="Kirim Invoice">
                                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"></path></svg>
                                </button>
                                @if($inv->status == 'unpaid')
                                    <button wire:click="openPaymentModal({{ $inv->id }})" class="p-1.5 text-green-600 border border-green-200 rounded hover:bg-green-50" title="Catat Pembayaran">
                                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                                    </button>
                                @else
                                    <button wire:click="openPaymentHistory({{ $inv->id }})" class="p-1.5 text-purple-600 border border-purple-200 rounded hover:bg-purple-50" title="Riwayat Pembayaran">
                                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"></path></svg>
                                    </button>
                                @endif
                                <button wire:click="edit({{ $inv->id }})" class="p-1.5 text-blue-600 border rounded hover:bg-blue-50" title="Edit">
                                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"></path></svg>
                                </button>
                                <button wire:click="delete({{ $inv->id }})" wire:confirm="Hapus?" class="p-1.5 text-red-600 border rounded hover:bg-red-50" title="Hapus">
                                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg>
                                </button>
                            </div>
                        </td>
                    </tr>
                    @empty
                    <tr><td colspan="7" class="px-6 py-12 text-center text-gray-500 italic">Belum ada invoice yang diterbitkan.</td></tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        <div class="p-4 border-t border-gray-100 bg-gray-50">{{ $invoices->links() }}</div>
    </div>

    {{-- MODAL CREATE/EDIT INVOICE --}}
    @if($isModalOpen)
    <div class="fixed inset-0 z-50 overflow-y-auto">
        <div class="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
            <div class="fixed inset-0 bg-gray-900/75 backdrop-blur-sm transition-opacity" wire:click="closeModal"></div>
            <span class="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>

            <div class="inline-block align-bottom bg-white rounded-2xl text-left overflow-hidden shadow-2xl transform transition-all sm:my-8 sm:align-middle sm:max-w-6xl sm:w-full border-t-8 border-blue-900">
                {{-- Header Modal --}}
                <div class="bg-gray-50 px-6 py-5 border-b border-gray-100 flex justify-between items-center">
                    <div>
                        <h3 class="text-xl font-black text-gray-900">{{ $isEditing ? 'Edit Invoice Detail' : 'Create New Invoice' }}</h3>
                        <p class="text-xs text-gray-400 font-bold uppercase tracking-widest mt-1">Sistem Penagihan Terpadu M2B</p>
                    </div>
                    <button wire:click="closeModal" type="button" class="text-gray-400 hover:text-gray-600 transition-colors">
                        <svg class="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" /></svg>
                    </button>
                </div>

                {{-- Content Modal --}}
                <div class="bg-white p-8">
                    @if ($errors->any())
                        <div class="bg-red-50 border-l-4 border-red-500 p-4 mb-6 rounded-r-lg">
                            <div class="flex items-center gap-3">
                                <svg class="h-5 w-5 text-red-400" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd"/></svg>
                                <p class="text-sm text-red-700 font-bold uppercase tracking-tight">Mohon lengkapi field yang ditandai merah (*)</p>
                            </div>
                        </div>
                    @endif

                    <div class="grid grid-cols-1 lg:grid-cols-4 gap-6 mb-8">
                                                {{-- Penerima Tagihan (Misal: RITRA) --}}
                        <div class="lg:col-span-2">
                            <label class="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1.5 ml-1">Penerima Tagihan (Bill-To) <span class="text-red-500">*</span></label>
                            <!-- Searchable Dropdown with Alpine.js -->
                            <div wire:ignore x-data="{
                                open: false,
                                search: '',
                                selected: @entangle('customer_id'),
                                selectedName: '',
                                customers: {{ Js::from($customersList->map(fn($c) => ['id' => $c->id, 'name' => $c->company_name])) }},
                                get filteredCustomers() {
                                    if (!this.search) return this.customers;
                                    return this.customers.filter(c => 
                                        c.name.toLowerCase().includes(this.search.toLowerCase())
                                    );
                                },
                                selectCustomer(customer) {
                                    this.selected = customer.id;
                                    this.selectedName = customer.name;
                                    this.search = '';
                                    this.open = false;
                                },
                                init() {
                                    if (this.selected) {
                                        const found = this.customers.find(c => c.id == this.selected);
                                        if (found) this.selectedName = found.name;
                                    }
                                    this.$watch('selected', (value) => {
                                        const found = this.customers.find(c => c.id == value);
                                        this.selectedName = found ? found.name : '';
                                    });
                                }
                            }" class="relative">
                                <div @click="open = !open" 
                                     class="w-full border border-gray-200 rounded-xl shadow-sm text-sm font-bold py-3 bg-white cursor-pointer flex items-center justify-between px-4 hover:border-blue-400 transition">
                                    <span x-text="selectedName || '-- Pilih Customer --'" :class="selectedName ? 'text-gray-800' : 'text-gray-400'"></span>
                                    <svg class="w-4 h-4 text-gray-400 transition-transform" :class="open && 'rotate-180'" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/>
                                    </svg>
                                </div>
                                
                                <div x-show="open" 
                                     x-transition
                                     @click.away="open = false"
                                     class="absolute z-50 mt-1 w-full bg-white border border-gray-200 rounded-xl shadow-lg max-h-64 overflow-hidden">
                                    
                                    <div class="p-2 border-b border-gray-100 sticky top-0 bg-white">
                                        <div class="relative">
                                            <svg class="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/>
                                            </svg>
                                            <input x-model="search" 
                                                   @click.stop
                                                   type="text" 
                                                   placeholder="🔍 Ketik untuk mencari customer..." 
                                                   class="w-full pl-9 pr-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                                        </div>
                                    </div>
                                    
                                    <div class="overflow-y-auto max-h-48">
                                        <template x-for="customer in filteredCustomers" :key="customer.id">
                                            <div @click="selectCustomer(customer)"
                                                 :class="selected == customer.id ? 'bg-blue-50 text-blue-700 font-bold' : 'hover:bg-gray-50'"
                                                 class="px-4 py-2.5 cursor-pointer text-sm flex items-center gap-2 transition">
                                                <span x-show="selected == customer.id" class="text-blue-500">✓</span>
                                                <span x-text="customer.name"></span>
                                            </div>
                                        </template>
                                        <div x-show="filteredCustomers.length === 0" class="px-4 py-4 text-sm text-gray-400 text-center">
                                            Tidak ada customer yang cocok
                                        </div>
                                    </div>
                                </div>
                                <input type="hidden" x-model="selected" wire:model.live="customer_id">
                            </div>
                            @error('customer_id') <span class="text-[10px] text-red-500 font-bold ml-1 uppercase">{{ $message }}</span> @enderror
                        </div>


                                                {{-- Shipment Reference (Misal: OCTO) --}}
                        <div class="lg:col-span-2">
                            <label class="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1.5 ml-1">Shipment Ref (Layanan Milik) <span class="text-red-500">*</span></label>
                            <!-- Searchable Dropdown with Alpine.js -->
                            <div wire:ignore x-data="{
                                open: false,
                                search: '',
                                selected: @entangle('shipment_id'),
                                selectedName: '',
                                shipments: {{ Js::from($customerShipments->map(fn($s) => ['id' => $s->id, 'name' => '[' . ($s->customer->company_name ?? 'N/A') . '] - ' . $s->awb_number, 'customer' => $s->customer->company_name ?? '', 'awb' => $s->awb_number])) }},
                                get filteredShipments() {
                                    if (!this.search) return this.shipments;
                                    const term = this.search.toLowerCase();
                                    return this.shipments.filter(s => 
                                        s.name.toLowerCase().includes(term) ||
                                        s.customer.toLowerCase().includes(term) ||
                                        s.awb.toLowerCase().includes(term)
                                    );
                                },
                                selectShipment(shipment) {
                                    this.selected = shipment.id;
                                    this.selectedName = shipment.name;
                                    this.search = '';
                                    this.open = false;
                                    setTimeout(() => this.selected = shipment.id, 100);
                                },
                                init() {
                                    if (this.selected) {
                                        const found = this.shipments.find(s => s.id == this.selected);
                                        if (found) this.selectedName = found.name;
                                    }
                                    this.$watch('selected', (value) => {
                                        const found = this.shipments.find(s => s.id == value);
                                        this.selectedName = found ? found.name : '';
                                    });
                                }
                            }" class="relative">
                                <div @click="open = !open" 
                                     class="w-full border border-gray-200 rounded-xl shadow-sm text-sm font-bold py-3 bg-white cursor-pointer flex items-center justify-between px-4 hover:border-blue-400 transition">
                                    <span x-text="$wire.shipment_name || '-- Pilih Shipment (Bisa Lintas Customer) --'" :class="selectedName ? 'text-gray-800' : 'text-gray-400'" class="truncate"></span>
                                    <svg class="w-4 h-4 text-gray-400 transition-transform flex-shrink-0" :class="open && 'rotate-180'" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/>
                                    </svg>
                                </div>
                                
                                <div x-show="open" 
                                     x-transition
                                     @click.away="open = false"
                                     class="absolute z-50 mt-1 w-full bg-white border border-gray-200 rounded-xl shadow-lg max-h-72 overflow-hidden">
                                    
                                    <div class="p-2 border-b border-gray-100 sticky top-0 bg-white">
                                        <div class="relative">
                                            <svg class="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/>
                                            </svg>
                                            <input x-model="search" 
                                                   @click.stop
                                                   type="text" 
                                                   placeholder="🔍 Cari customer atau AWB number..." 
                                                   class="w-full pl-9 pr-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                                        </div>
                                    </div>
                                    
                                    <div class="overflow-y-auto max-h-56">
                                        <template x-for="shipment in filteredShipments" :key="shipment.id">
                                            <div @click="selectShipment(shipment)"
                                                 :class="selected == shipment.id ? 'bg-blue-50 text-blue-700 font-bold' : 'hover:bg-gray-50'"
                                                 class="px-4 py-2.5 cursor-pointer text-sm flex items-center gap-2 transition">
                                                <span x-show="selected == shipment.id" class="text-blue-500 flex-shrink-0">✓</span>
                                                <span x-text="shipment.name" class="truncate"></span>
                                            </div>
                                        </template>
                                        <div x-show="filteredShipments.length === 0" class="px-4 py-4 text-sm text-gray-400 text-center">
                                            Tidak ada shipment yang cocok
                                        </div>
                                    </div>
                                </div>
                                <input type="hidden" x-model="selected" wire:model.live="shipment_id">
                            </div>
                            @error('shipment_id') <span class="text-[10px] text-red-500 font-bold ml-1 uppercase">{{ $message }}</span> @enderror
                        </div>


                        <div>
                            <label class="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1.5 ml-1">Tipe Dokumen</label>
                            <select wire:model.live="type" class="w-full border-gray-200 rounded-xl shadow-sm text-sm font-black text-blue-900 py-3">
                                <option value="Commercial">COMMERCIAL</option>
                                <option value="Proforma">PROFORMA</option>
                            </select>
                        </div>
                        <div>
                            <label class="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1.5 ml-1">Invoice Number</label>
                            <input type="text" wire:model="invoice_number" class="w-full border-gray-200 rounded-xl shadow-sm bg-gray-50 text-gray-400 font-mono text-sm py-3 px-4" readonly>
                        </div>
                        <div>
                            <label class="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1.5 ml-1">Invoice Date</label>
                            <input type="date" wire:model="invoice_date" class="w-full border-gray-200 rounded-xl shadow-sm text-sm py-3 px-4">
                        </div>
                        <div>
                            <label class="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1.5 ml-1">Due Date</label>
                            <input type="date" wire:model="due_date" class="w-full border-gray-200 rounded-xl shadow-sm text-sm py-3 px-4">
                        </div>
                        <div>
                            <label class="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1.5 ml-1">Bahasa Terbilang</label>
                            <select wire:model="terbilang_lang" class="w-full border-gray-200 rounded-xl shadow-sm text-sm font-black text-blue-900 py-3">
                                <option value="id">🇮🇩 Indonesia</option>
                                <option value="en">🇬🇧 English</option>
                                <option value="both">🌐 Both (ID + EN)</option>
                            </select>
                        </div>
                        {{-- Catatan Pembayaran --}}
                        <div class="lg:col-span-2">
                            <label class="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1.5 ml-1">Catatan Pembayaran / Payment Notes (Opsional)</label>
                            <textarea wire:model="payment_notes" rows="2" class="w-full border-gray-200 rounded-xl shadow-sm text-sm py-3 px-4" placeholder="Contoh: Pembayaran dapat dicicil 2x, atau catatan khusus lainnya..."></textarea>
                        </div>
                    </div>

                    {{-- ITEMS TABLE --}}
                    <div class="bg-gray-50 rounded-2xl border border-gray-100 overflow-hidden mb-8 shadow-inner">
                        <div class="overflow-x-auto">
                            <table class="min-w-full divide-y divide-gray-200">
                                <thead class="bg-gray-100/50">
                                    <tr class="text-[10px] font-black text-gray-500 uppercase tracking-widest">
                                        <th class="px-6 py-4 text-left">Layanan / Item Jasa</th>
                                        <th class="px-6 py-4 text-left">Jenis</th>
                                        <th class="px-6 py-4 text-center">Qty</th>
                                        <th class="px-6 py-4 text-right">Unit Price (IDR)</th>
                                        <th class="px-6 py-4 text-right">Total (IDR)</th>
                                        <th class="px-6 py-4 w-10"></th>
                                    </tr>
                                </thead>
                                <tbody class="bg-white divide-y divide-gray-100">
                                    @foreach($items as $index => $item)
                                    <tr class="hover:bg-blue-50/30 transition">
                                        <td class="px-6 py-3">
                                            <div class="space-y-1.5">
                                                <select wire:model.live="items.{{ $index }}.product_id" wire:change="selectProduct({{ $index }}, $event.target.value)" class="w-full border-gray-200 rounded-lg text-xs font-bold py-1.5">
                                                    <option value="">-- Pilih Master Layanan --</option>
                                                    @foreach($products as $product)
                                                        <option value="{{ $product['id'] }}">{{ $product['name'] }}</option>
                                                    @endforeach
                                                </select>
                                                <input type="text" wire:model="items.{{ $index }}.description" class="w-full border-gray-200 rounded-lg text-xs py-1.5" placeholder="Keterangan tambahan...">
                                            </div>
                                        </td>
                                        <td class="px-6 py-3">
                                            <select wire:model.live="items.{{ $index }}.item_type" wire:change="calculateGrandTotal" class="w-full border-gray-200 rounded-lg text-[10px] font-black uppercase py-1.5 {{ ($item['item_type'] ?? 'service') == 'reimbursement' ? 'text-green-600 bg-green-50 border-green-100' : 'text-blue-600 bg-blue-50 border-blue-100' }}">
                                                <option value="service">Jasa (PPN)</option>
                                                <option value="reimbursement">Penerusan (Reimb)</option>
                                            </select>
                                        </td>
                                        <td class="px-6 py-3">
                                            <input type="number" wire:model.live="items.{{ $index }}.qty" wire:change="calculateTotal({{ $index }})" class="w-16 border-gray-200 rounded-lg text-xs text-center py-1.5">
                                        </td>
                                        <td class="px-6 py-3">
                                            <input type="number" wire:model.live="items.{{ $index }}.price" wire:change="calculateTotal({{ $index }})" class="w-full border-gray-200 rounded-lg text-xs text-right font-mono py-1.5">
                                        </td>
                                        <td class="px-6 py-3 text-right">
                                            <span class="text-sm font-mono font-black text-gray-800">IDR {{ number_format($item['total'], 0, ',', '.') }}</span>
                                        </td>
                                        <td class="px-6 py-3 text-center">
                                            <button wire:click="removeItem({{ $index }})" class="text-red-300 hover:text-red-600 transition"><svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg></button>
                                        </td>
                                    </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                        <div class="p-4 bg-gray-100/50">
                            <button wire:click="addItem" class="text-[10px] text-blue-700 font-black uppercase tracking-[0.2em] hover:text-blue-900 flex items-center gap-2">
                                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"></path></svg>
                                Add Row Item
                            </button>
                        </div>
                    </div>

                    {{-- LOGIKA FINANCIALS (RESTRUCTURED) --}}
<div class="grid grid-cols-1 lg:grid-cols-2 gap-8">

    {{-- KIRI: SUB TOTAL & DETAIL --}}
    <div class="space-y-4">

        <div class="flex justify-between items-center text-blue-900">
    <span class="text-sm font-bold">Sub-Total Jasa (Service)</span>
    <span class="font-mono text-xl font-black">
        IDR {{ number_format($service_total, 0, ',', '.') }}
    </span>
</div>


        <div class="grid grid-cols-2 gap-4">
            <div class="p-3 bg-gray-50 rounded-xl border border-gray-100">
                <label class="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2">
                    Pajak PPN (%)
                </label>
                <div class="flex items-center gap-3">
                    <input type="number"
                        wire:model.live.debounce.500ms="tax_rate"
                        class="w-16 border-gray-200 rounded-lg text-xs font-bold text-center">
                    <span class="text-sm font-mono font-black text-gray-800">
    IDR {{ number_format($tax_amount, 0, ',', '.') }}
</span>

                </div>
            </div>

            <div class="p-3 bg-gray-50 rounded-xl border border-gray-100">
                <label class="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2">
                    Potong PPh (%)
                </label>
                <div class="flex items-center gap-3">
                    <input type="number"
                        wire:model.live.debounce.500ms="pph_rate"
                        class="w-16 border-gray-200 rounded-lg text-xs font-bold text-center">
                    <span class="text-sm font-mono font-black text-red-600">
    ({{ number_format($pph_amount, 0, ',', '.') }})
</span>

                </div>
            </div>
        </div>

        <div class="flex justify-between items-center text-green-700">
    <span class="text-sm font-bold">Reimbursement (Penerusan)</span>
    <span class="font-mono text-xl font-black">
        IDR {{ number_format($reimbursement_total, 0, ',', '.') }}
    </span>
</div>


        <div class="flex justify-between items-center text-gray-800 text-sm border-t border-dashed border-gray-200 pt-3">
            <div class="flex items-center gap-2 uppercase font-black text-[10px] text-gray-400">
                Discount (%)
                <input type="number"
                    wire:model.live.debounce.500ms="discount_percentage"
                    class="w-12 border-gray-200 rounded-lg text-center p-1 font-bold text-gray-700">
            </div>
            <span class="font-mono text-sm font-bold text-red-600">
    ({{ number_format($discount_amount, 0, ',', '.') }})
</span>

        </div>

    </div>

    {{-- KANAN: GRAND TOTAL (NAIK KE ATAS & SEJAJAR) --}}
    <div class="self-start bg-slate-900 rounded-3xl p-8 shadow-2xl">

        <div class="flex justify-between items-center mb-6">
            <span class="text-[10px] font-black text-blue-300 uppercase tracking-[0.4em]">
                Grand Total Billing
            </span>
            <span class="text-3xl font-mono font-black text-white tracking-tight">
                IDR {{ number_format($grand_total, 0, ',', '.') }}
            </span>
        </div>

        {{-- LESS DP --}}
        @if($type == 'Commercial')
        <div class="p-4 bg-white/5 rounded-2xl border border-white/10 flex justify-between items-center">
            <div class="flex items-center gap-3">
                <span class="text-[10px] font-black text-red-400 uppercase tracking-widest">
                    Less Down Payment (DP)
                </span>
                <input type="number"
                    wire:model.live.debounce.500ms="down_payment"
                    class="w-28 border-none bg-white/10 text-white rounded-lg text-xs font-mono font-bold text-right py-1">
            </div>
            <span class="font-mono text-sm text-red-400 font-bold">
                ({{ number_format($down_payment, 0, ',', '.') }})
            </span>
        </div>
        @else
        <div class="flex items-center gap-4 bg-white/10 p-4 rounded-2xl border border-white/10">
            <span class="text-[10px] font-black text-blue-300 uppercase tracking-widest">
                Simulation DP (%)
            </span>
            <input type="number"
                wire:model.live.debounce.500ms="dp_percentage"
                class="w-20 border-none bg-blue-600 text-white rounded-lg text-xs font-bold text-center py-1.5 shadow-lg">
            <p class="text-[9px] text-white/40 italic flex-1">
                Invoice Proforma akan diterbitkan senilai {{ $dp_percentage }}% dari grand total.
            </p>
        </div>
        @endif

    </div>
</div>


                {{-- Footer Modal Aksi --}}
                <div class="bg-gray-100 px-8 py-6 flex justify-between items-center border-t border-gray-200">
                    <button wire:click="closeModal" type="button" class="text-xs font-black text-gray-400 uppercase tracking-[0.2em] hover:text-gray-700 transition-colors">Batal / Kembali</button>
                    
                    <button wire:click="save" wire:loading.attr="disabled" type="button" class="bg-blue-900 text-white px-10 py-4 rounded-2xl font-black text-sm uppercase tracking-[0.3em] shadow-2xl hover:bg-blue-800 transition-all transform hover:scale-[1.02] flex items-center gap-3">
                        <span wire:loading.remove wire:target="save">Simpan & Terbitkan</span>
                        <svg wire:loading wire:target="save" class="animate-spin h-5 w-5 text-white" fill="none" viewBox="0 0 24 24"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>
                        <span wire:loading wire:target="save">Processing...</span>
                    </button>
                </div>
            </div>
        </div>
    </div>
    @endif
    
    {{-- MODAL PAYMENT dengan Partial Payment Support --}}
    @if($isPaymentModalOpen)
    <div class="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm">
        <div class="bg-white rounded-3xl shadow-2xl w-full max-w-md animate-fade-in-up border-t-8 border-green-600 overflow-hidden">
            <div class="p-6 border-b border-gray-50 flex justify-between items-center">
                <h3 class="font-black text-lg text-gray-800 uppercase tracking-widest">Catat Pembayaran</h3>
                <button wire:click="closePaymentModal" class="text-gray-400 hover:text-red-500 transition-colors text-2xl">&times;</button>
            </div>
            <div class="p-6 space-y-4">
                {{-- Invoice Summary --}}
                @if($selectedInvoiceForPayment)
                <div class="bg-gradient-to-r from-blue-50 to-green-50 p-4 rounded-2xl border">
                    <div class="flex justify-between items-start mb-3">
                        <span class="font-black text-blue-800">{{ $selectedInvoiceForPayment->invoice_number }}</span>
                        <span class="text-xs text-gray-500">{{ $selectedInvoiceForPayment->customer->company_name ?? "-" }}</span>
                    </div>
                    <div class="grid grid-cols-3 gap-2 text-center">
                        <div class="bg-white/80 rounded-xl p-2">
                            <div class="text-[10px] text-gray-400 uppercase">Total</div>
                            <div class="font-black text-gray-800 text-sm">{{ number_format($selectedInvoiceForPayment->grand_total, 0, ",", ".") }}</div>
                        </div>
                        <div class="bg-white/80 rounded-xl p-2">
                            <div class="text-[10px] text-gray-400 uppercase">Dibayar</div>
                            <div class="font-black text-green-600 text-sm">{{ number_format($selectedInvoiceForPayment->total_paid ?? 0, 0, ",", ".") }}</div>
                        </div>
                        <div class="bg-white/80 rounded-xl p-2">
                            <div class="text-[10px] text-gray-400 uppercase">Sisa</div>
                            <div class="font-black text-red-600 text-sm">{{ number_format($selectedInvoiceForPayment->grand_total - ($selectedInvoiceForPayment->total_paid ?? 0), 0, ",", ".") }}</div>
                        </div>
                    </div>
                </div>
                @endif
                {{-- Info --}}
                <div class="bg-green-50 p-3 rounded-xl border border-green-100 flex items-center gap-3">
                    <div class="bg-green-600 text-white p-1.5 rounded-lg"><svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path></svg></div>
                    <p class="text-xs text-green-800 font-bold">Pastikan dana sudah masuk ke rekening perusahaan.</p>
                </div>
                {{-- Jumlah Pembayaran --}}
                <div>
                    <label class="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1.5">Jumlah Pembayaran (Rp)</label>
                    <input type="number" wire:model="amount" class="w-full border-gray-200 rounded-xl text-sm font-bold py-3 text-right" placeholder="0">
                </div>
                {{-- Tanggal & Metode --}}
                <div class="grid grid-cols-2 gap-3">
                    <div><label class="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1.5">Tanggal Bayar</label><input type="date" wire:model="payment_date" class="w-full border-gray-200 rounded-xl text-sm font-bold py-3"></div>
                    <div><label class="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1.5">Metode Bayar</label><select wire:model="payment_method" class="w-full border-gray-200 rounded-xl text-sm font-bold py-3"><option>Transfer Bank</option><option>Cash</option><option>Giro</option></select></div>
                </div>
                {{-- Catatan --}}
                <div><label class="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1.5">Catatan (Opsional)</label><input type="text" wire:model="payment_note" class="w-full border-gray-200 rounded-xl text-sm py-3" placeholder="Contoh: DP 50%"></div>
                {{-- Bukti --}}
                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-2">Bukti Transfer</label>
                    <input type="file" id="payment_proof_input" class="block w-full text-sm text-gray-900 border border-gray-300 rounded-lg cursor-pointer bg-white focus:outline-none" accept="image/jpeg,image/png,image/jpg,application/pdf" onchange="@this.upload('quick_payment_proof', this.files[0])">
                    <p class="mt-1 text-xs text-gray-500">📎 Opsional: Upload bukti transfer (JPG, PNG, PDF max 10MB). Bisa juga diupload nanti dari detail invoice.</p>
                    @error('quick_payment_proof') <span class="text-red-500 text-xs">{{ $message }}</span> @enderror
                    <div wire:loading wire:target="quick_payment_proof" class="text-xs text-blue-600 mt-1">Uploading file...</div>
                </div>
                {{-- Buttons --}}
                <div class="flex justify-between gap-4 mt-4">
                    <button wire:click="closePaymentModal" class="flex-1 py-3 text-xs font-black text-gray-400 uppercase tracking-widest hover:text-gray-700 transition border rounded-xl">Batal</button>
                    <button wire:click="savePaymentNew" class="flex-1 py-3 bg-green-600 text-white rounded-xl font-black text-xs uppercase tracking-widest hover:bg-green-700 transition-all">Simpan Pembayaran</button>
                </div>
            </div>
        </div>
    </div>
    @endif

    @if($isPaymentPreviewOpen)
    <div class="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/80 p-4 backdrop-blur-sm" wire:click.self="closePaymentPreview">
        <div class="bg-white rounded-3xl shadow-2xl max-w-4xl w-full overflow-hidden animate-zoom-in border-t-8 border-purple-600">
            <div class="p-6 border-b flex justify-between items-center bg-gray-50">
                <h3 class="font-black text-gray-800 uppercase tracking-widest">Bukti Pembayaran Digital</h3>
                <button wire:click="closePaymentPreview" class="text-gray-400 hover:text-red-500 transition-all text-2xl leading-none">&times;</button>
            </div>
            <div class="p-8 text-center bg-gray-200/50 shadow-inner">
                @if($payment_proof_url)
                    @if(Str::endsWith($payment_proof_url, '.pdf')) 
                        <iframe src="{{ $payment_proof_url }}" class="w-full h-[60vh] border-none rounded-2xl shadow-lg"></iframe> 
                    @else 
                        <img src="{{ $payment_proof_url }}" class="max-h-[70vh] mx-auto rounded-2xl shadow-2xl border-8 border-white"> 
                    @endif
                @else 
                    <div class="py-20 text-gray-400 italic font-bold">File bukti bayar tidak ditemukan di storage.</div> 
                @endif
            </div>
            <div class="p-4 bg-white text-center">
                 <a href="{{ $payment_proof_url }}" target="_blank" class="text-xs font-black text-blue-600 uppercase tracking-widest hover:underline">Download Bukti Original</a>
            </div>
        </div>
    </div>
    @endif

    @if($isSendModalOpen)
    <div class="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm">
        <div class="bg-white rounded-3xl shadow-2xl w-full max-w-xl animate-fade-in-up overflow-hidden border-t-8 border-blue-900">
            <div class="px-8 py-6 border-b bg-gray-50/50 flex justify-between items-center">
                <div>
                    <h3 class="font-black text-lg text-gray-800 uppercase tracking-widest flex items-center gap-2">
                        <svg class="w-5 h-5 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"></path></svg>
                        Kirim Tagihan Elektronik
                    </h3>
                    <p class="text-[10px] text-gray-400 font-bold uppercase tracking-widest mt-1">Otomatisasi Email PT. M2B</p>
                </div>
                <button wire:click="closeSendModal" class="text-gray-400 hover:text-red-500 transition-colors text-2xl">&times;</button>
            </div>
            
            <div class="p-8 space-y-6">
                <div class="bg-green-50 border border-green-100 rounded-2xl p-5 flex justify-between items-center">
                    <div class="text-xs text-green-800 flex items-center gap-3">
                        <div class="bg-green-600 text-white p-2 rounded-xl shadow-lg shadow-green-100"><svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5h12M9 3v2m1.048 9.5A18.022 18.022 0 016.412 9m6.088 9h7M11 21l5-10 5 10M12.751 5C11.783 10.77 8.07 15.61 3 18.129"></path></svg></div>
                        <div><span class="font-black block uppercase tracking-wider">Cetak PDF Terlebih Dahulu?</span> Untuk preview visual dokumen sebelum dikirim.</div>
                    </div>
                    <a href="{{ route('admin.invoices.print', $sendingInvoiceId) }}" target="_blank" class="bg-white border border-green-200 text-green-600 text-[10px] px-4 py-2 rounded-xl font-black uppercase tracking-widest hover:bg-green-50 transition-all shadow-sm">Preview PDF</a>
                </div>

                <div class="space-y-4">
                    <div>
                        <label class="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1.5 ml-1">Email Penerima</label>
                        <input type="email" wire:model="email_recipient" class="w-full border-gray-200 rounded-xl text-sm font-bold focus:border-blue-500 focus:ring-1 focus:ring-blue-500 py-3 shadow-sm" placeholder="finance@customer.com">
                        @error('email_recipient') <span class="text-[10px] text-red-500 font-bold uppercase ml-1">{{ $message }}</span> @enderror
                    </div>
                    <div>
                        <label class="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1.5 ml-1">Subjek Email</label>
                        <input type="text" wire:model="email_subject" class="w-full border-gray-200 rounded-xl text-sm font-bold focus:border-blue-500 focus:ring-1 focus:ring-blue-500 py-3 shadow-sm">
                        @error('email_subject') <span class="text-[10px] text-red-500 font-bold uppercase ml-1">{{ $message }}</span> @enderror
                    </div>
                    <div>
                        <label class="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1.5 ml-1">Pesan / Body Email</label>
                        <textarea wire:model="email_body" rows="6" class="w-full border-gray-200 rounded-xl text-xs focus:border-blue-500 focus:ring-1 focus:ring-blue-500 font-mono py-3 bg-gray-50/50"></textarea>
                        @error('email_body') <span class="text-[10px] text-red-500 font-bold uppercase ml-1">{{ $message }}</span> @enderror
                    </div>
                </div>
            </div>

            <div class="px-8 py-5 bg-gray-50 flex justify-between items-center border-t">
                <button wire:click="closeSendModal" class="text-xs font-black text-gray-400 uppercase tracking-widest hover:text-gray-600 transition">Batal</button>
                <button wire:click="sendEmail" wire:loading.attr="disabled" class="bg-blue-900 text-white px-8 py-3 rounded-xl font-black text-xs uppercase tracking-widest hover:bg-blue-800 transition-all shadow-xl flex items-center gap-3">
                    <span wire:loading.remove wire:target="sendEmail">Kirim Ke Customer 🚀</span>
                    <svg wire:loading wire:target="sendEmail" class="animate-spin h-4 w-4 text-white" fill="none" viewBox="0 0 24 24"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>
                    <span wire:loading wire:target="sendEmail">Mengirim Dokumen...</span>
                </button>
            </div>
        </div>
    </div>
    @endif

    {{-- MODAL: Payment History --}}
    @if($paymentHistoryModal)
    <div class="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm">
        <div class="bg-white rounded-2xl shadow-2xl w-full max-w-lg overflow-hidden border-t-8 border-purple-600">
            <div class="p-6 border-b flex justify-between items-center bg-gray-50">
                <h3 class="font-black text-gray-800 uppercase tracking-widest">Riwayat Pembayaran</h3>
                <button wire:click="closePaymentHistory" class="text-gray-400 hover:text-red-500 text-2xl">&times;</button>
            </div>
            <div class="p-6">
                @if($selectedInvoiceForPayment)
                <div class="bg-blue-50 p-4 rounded-xl mb-4">
                    <div class="font-bold text-blue-800">{{ $selectedInvoiceForPayment->invoice_number }}</div>
                    <div class="text-sm text-gray-600">{{ $selectedInvoiceForPayment->customer->company_name ?? "-" }}</div>
                    <div class="mt-2 flex justify-between text-sm">
                        <span>Total: <b>Rp {{ number_format($selectedInvoiceForPayment->grand_total, 0, ",", ".") }}</b></span>
                        <span class="text-green-600">Dibayar: <b>Rp {{ number_format($selectedInvoiceForPayment->total_paid ?? 0, 0, ",", ".") }}</b></span>
                    </div>
                </div>
                @endif
                {{-- Tombol Tambah Pembayaran Baru --}}
                @if($selectedInvoiceForPayment && $selectedInvoiceForPayment->status != 'paid')
                <div class="mb-4">
                    <button wire:click="openPaymentModal({{ $selectedInvoiceForPayment->id }})" class="w-full py-3 bg-green-600 hover:bg-green-700 text-white rounded-xl font-bold text-sm flex items-center justify-center gap-2 transition">
                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"></path></svg>
                        Tambah Pembayaran Baru
                    </button>
                </div>
                @endif
                <div class="space-y-2 max-h-80 overflow-y-auto">
                    @forelse($selectedInvoicePayments as $pmt)
                    <div class="bg-gray-50 p-4 rounded-xl flex justify-between items-center">
                        <div>
                            <div class="font-bold text-gray-800">Rp {{ number_format($pmt['amount'], 0, ",", ".") }}</div>
                            <div class="text-xs text-gray-500">{{ date("d M Y", strtotime($pmt['payment_date'])) }} - {{ $pmt['payment_method'] }}</div>
                            @if(!empty($pmt['notes']))<div class="text-xs text-gray-400 mt-1">{{ $pmt['notes'] }}</div>@endif
                        </div>
                        <div class="flex items-center gap-1">
                            @if(!empty($pmt['proof_file']))
                            <button wire:click="openFilePreview({{ $pmt['id'] }})" class="p-1.5 text-purple-600 hover:bg-purple-100 rounded-lg" title="Lihat Bukti">
                                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"></path></svg>
                            </button>
                            @endif
                            <button wire:click="editPayment({{ $pmt['id'] }})" class="p-1.5 text-blue-600 hover:bg-blue-100 rounded-lg" title="Edit">
                                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"></path></svg>
                            </button>
                            <button wire:click="deletePayment({{ $pmt['id'] }})" wire:confirm="Hapus pembayaran ini?" class="p-1.5 text-red-500 hover:bg-red-100 rounded-lg" title="Hapus">
                                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg>
                            </button>
                        </div>
                    </div>
                    @empty
                    {{-- Check legacy payment_proof --}}
                    @if($selectedInvoiceForPayment && $selectedInvoiceForPayment->payment_proof)
                    <div class="bg-gray-50 p-4 rounded-xl">
                        <div class="flex justify-between items-center">
                            <div>
                                <div class="font-bold text-gray-800">Rp {{ number_format($selectedInvoiceForPayment->grand_total, 0, ",", ".") }}</div>
                                <div class="text-xs text-gray-500">{{ $selectedInvoiceForPayment->payment_date ? $selectedInvoiceForPayment->payment_date->format("d M Y") : "-" }} - {{ $selectedInvoiceForPayment->payment_method ?? "Transfer Bank" }}</div>
                                <div class="text-xs text-gray-400 mt-1">Pembayaran tercatat sebelum sistem baru</div>
                            </div>
                            <button wire:click="openFilePreview('{{ $selectedInvoiceForPayment->payment_proof }}')" class="text-purple-600 hover:text-purple-800 p-2 bg-purple-50 rounded-lg" title="Lihat Bukti">
                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"></path></svg>
                            </button>
                        </div>
                    </div>
                    @else
                    <div class="text-center py-8 text-gray-400 italic">Belum ada pembayaran tercatat.</div>
                    @endif
                    @endforelse
                </div>
            </div>
        </div>
    </div>
    @endif

    {{-- MODAL: Edit Payment --}}
    @if($isEditPaymentModalOpen)
    <div class="fixed inset-0 z-[60] flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm">
        <div class="bg-white rounded-2xl shadow-2xl w-full max-w-md overflow-hidden border-t-8 border-blue-600">
            <div class="p-5 border-b flex justify-between items-center bg-gray-50">
                <h3 class="font-black text-gray-800 uppercase tracking-widest">Edit Pembayaran</h3>
                <button wire:click="closeEditPaymentModal" class="text-gray-400 hover:text-red-500 text-2xl">&times;</button>
            </div>
            <div class="p-5 space-y-4">
                <div>
                    <label class="block text-xs font-bold text-gray-500 uppercase mb-1">Jumlah Pembayaran</label>
                    <input type="number" wire:model="editingPaymentAmount" class="w-full border-gray-200 rounded-xl py-2.5 font-bold text-lg focus:border-blue-500 focus:ring-blue-500">
                    @error('editingPaymentAmount')<span class="text-xs text-red-500">{{ $message }}</span>@enderror
                </div>
                <div>
                    <label class="block text-xs font-bold text-gray-500 uppercase mb-1">Tanggal</label>
                    <input type="date" wire:model="editingPaymentDate" class="w-full border-gray-200 rounded-xl py-2.5 focus:border-blue-500 focus:ring-blue-500">
                    @error('editingPaymentDate')<span class="text-xs text-red-500">{{ $message }}</span>@enderror
                </div>
                <div>
                    <label class="block text-xs font-bold text-gray-500 uppercase mb-1">Metode</label>
                    <select wire:model="editingPaymentMethod" class="w-full border-gray-200 rounded-xl py-2.5 focus:border-blue-500 focus:ring-blue-500">
                        <option value="Transfer Bank">Transfer Bank</option>
                        <option value="Cash">Cash</option>
                        <option value="Giro">Giro</option>
                        <option value="Kartu Kredit">Kartu Kredit</option>
                        <option value="E-Wallet">E-Wallet</option>
                    </select>
                </div>
                <div>
                    <label class="block text-xs font-bold text-gray-500 uppercase mb-1">Catatan</label>
                    <textarea wire:model="editingPaymentNote" rows="2" class="w-full border-gray-200 rounded-xl py-2.5 text-sm focus:border-blue-500 focus:ring-blue-500" placeholder="Opsional..."></textarea>
                </div>
                <div>
                    <label class="block text-xs font-bold text-gray-500 uppercase mb-1">Upload Bukti Baru</label>
                    <input type="file" wire:model="editingPaymentProof" class="w-full border border-gray-200 rounded-xl py-2 px-3 text-sm file:mr-3 file:py-1.5 file:px-3 file:rounded-lg file:border-0 file:bg-blue-50 file:text-blue-700 file:font-bold file:text-xs">
                    <div class="text-xs text-gray-400 mt-1">JPG, PNG, PDF (max 10MB)</div>
                    @error('editingPaymentProof')<span class="text-xs text-red-500">{{ $message }}</span>@enderror
                    <div wire:loading wire:target="editingPaymentProof" class="text-xs text-blue-500 mt-1">Mengupload...</div>
                </div>
            </div>
            <div class="p-4 bg-gray-50 border-t flex justify-between">
                <button wire:click="closeEditPaymentModal" class="px-5 py-2 bg-gray-200 hover:bg-gray-300 rounded-xl font-bold text-sm text-gray-600">Batal</button>
                <div class="flex gap-2">
                    <button wire:click="savePaymentProof" wire:loading.attr="disabled" class="px-5 py-2 bg-orange-500 hover:bg-orange-600 text-white rounded-xl font-bold text-sm disabled:opacity-50">
                        <span wire:loading.remove wire:target="savePaymentProof">Upload Bukti</span>
                        <span wire:loading wire:target="savePaymentProof">Proses...</span>
                    </button>
                    <button wire:click="updatePayment" wire:loading.attr="disabled" class="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-bold text-sm disabled:opacity-50">
                        <span wire:loading.remove wire:target="updatePayment">Simpan</span>
                        <span wire:loading wire:target="updatePayment">Proses...</span>
                    </button>
                </div>
            </div>
        </div>
    </div>
    @endif

    {{-- MODAL: Image/PDF Preview --}}
    @if($previewFileModal ?? false)
    <div class="fixed inset-0 z-[70] flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm" wire:click.self="closeFilePreview">
        <div class="bg-white rounded-2xl shadow-2xl w-full max-w-4xl max-h-[90vh] overflow-hidden">
            <div class="p-4 border-b flex justify-between items-center bg-gray-50">
                <h3 class="font-black text-gray-800 uppercase tracking-widest text-sm">Preview Bukti Pembayaran</h3>
                <div class="flex items-center gap-2">
                    <a href="{{ asset('storage/' . $previewFilePath) }}" download class="px-4 py-2 bg-blue-600 text-white rounded-lg text-xs font-bold hover:bg-blue-700 flex items-center gap-2">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"></path></svg>
                        Download
                    </a>
                    <button wire:click="closeFilePreview" class="text-gray-400 hover:text-red-500 text-2xl px-2">&times;</button>
                </div>
            </div>
            <div class="p-4 bg-gray-100 overflow-auto max-h-[75vh] flex items-center justify-center" x-data="{ scale: 1 }">
                @if($previewFilePath && str_contains(strtolower($previewFilePath), '.pdf'))
                    <iframe src="{{ asset('storage/' . $previewFilePath) }}" class="w-full h-[70vh] rounded-lg"></iframe>
                @else
                    <div class="text-center">
                        <div class="mb-3 flex justify-center gap-2">
                            <button @click="scale = Math.max(0.5, scale - 0.25)" class="px-3 py-1 bg-gray-200 rounded-lg text-sm font-bold hover:bg-gray-300">−</button>
                            <span class="px-3 py-1 bg-white rounded-lg text-sm font-bold" x-text="Math.round(scale * 100) + '%'"></span>
                            <button @click="scale = Math.min(3, scale + 0.25)" class="px-3 py-1 bg-gray-200 rounded-lg text-sm font-bold hover:bg-gray-300">+</button>
                            <button @click="scale = 1" class="px-3 py-1 bg-gray-200 rounded-lg text-sm font-bold hover:bg-gray-300">Reset</button>
                        </div>
                        <img src="{{ asset('storage/' . $previewFilePath) }}" 
                             class="max-w-full rounded-lg shadow-lg transition-transform duration-200 cursor-move" 
                             :style="'transform: scale(' + scale + ')'"
                             alt="Bukti Pembayaran">
                    </div>
                @endif
            </div>
        </div>
    </div>
    @endif

    <!-- Modal Faktur Pajak -->
    @if($fakturPajakInvoiceId)
    <div class="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm" wire:click.self="$set('fakturPajakInvoiceId', null)">
        <div class="bg-white rounded-2xl shadow-2xl w-full max-w-md mx-4 overflow-hidden">
            <div class="bg-gradient-to-r from-blue-600 to-blue-700 px-6 py-4 flex justify-between items-center">
                <h3 class="text-lg font-bold text-white">Upload Faktur Pajak</h3>
                <button wire:click="$set('fakturPajakInvoiceId', null)" class="text-white/80 hover:text-white text-2xl">&times;</button>
            </div>
            <form wire:submit.prevent="saveFakturPajak" class="p-6 space-y-4">
                <div>
                    <label class="block text-sm font-bold text-gray-700 mb-2">Nomor Faktur Pajak</label>
                    <input type="text" wire:model="fakturPajakNumber" class="w-full border-2 border-gray-200 rounded-xl px-4 py-3 focus:border-blue-500 focus:ring-0" placeholder="000.000-00.00000000">
                    @error('fakturPajakNumber') <span class="text-red-500 text-xs mt-1">{{ $message }}</span> @enderror
                </div>
                <div>
                    <label class="block text-sm font-bold text-gray-700 mb-2">File PDF Faktur Pajak</label>
                    <input type="file" wire:model="fakturPajakFile" accept=".pdf" class="w-full border-2 border-gray-200 rounded-xl px-4 py-3 focus:border-blue-500">
                    <div wire:loading wire:target="fakturPajakFile" class="text-xs text-blue-500 mt-1">Uploading...</div>
                    @error('fakturPajakFile') <span class="text-red-500 text-xs mt-1">{{ $message }}</span> @enderror
                </div>
                <div class="flex gap-3 pt-2">
                    <button type="button" wire:click="$set('fakturPajakInvoiceId', null)" class="flex-1 py-3 text-sm font-bold text-gray-500 bg-gray-100 rounded-xl hover:bg-gray-200">Batal</button>
                    <button type="submit" class="flex-1 py-3 text-sm font-bold text-white bg-blue-600 rounded-xl hover:bg-blue-700" wire:loading.attr="disabled">
                        <span wire:loading.remove wire:target="saveFakturPajak">Simpan</span>
                        <span wire:loading wire:target="saveFakturPajak">Menyimpan...</span>
                    </button>
                </div>
            </form>
        </div>
    </div>
    @endif
</div>