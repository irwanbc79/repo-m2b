<?php

namespace App\Livewire\Admin;

use Livewire\Component;

class FieldPhotoUpload extends Component
{
    public function render()
    {
        return view('livewire.admin.field-photo-upload');
    }
}
