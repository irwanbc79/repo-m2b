<?php

namespace App\Livewire\Customer;

use Livewire\Component;
use Livewire\Attributes\On;
use App\Models\Customer;
use App\Models\User;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rule;

class Create extends Component
{
    // State Modal
    public $isOpen = false;
    public $isEditing = false;
    public $customerId;
    public $userId;

    // Form Variables
    public $code;
    public $companyName;
    public $name; // Nama PIC
    public $email;
    public $password;
    public $phone;
    public $city;
    public $address; // Alamat Fisik/Kantor
    
    // Data Pajak & Gudang
    public $npwp;
    public $taxAddress;
    public $warehouseAddress; 

    // Feature Variable (Wajib ada agar tidak error di Blade)
    public $useOfficeAsWarehouse = false; 

    // --- LOGIC TAMBAHAN (Agar Checkbox Berfungsi) ---

    // 1. Saat checkbox dicentang, copy alamat kantor ke gudang
    public function updatedUseOfficeAsWarehouse($value)
    {
        if ($value) {
            $this->warehouseAddress = $this->address;
        }
    }

    // 2. Saat mengetik alamat kantor, jika checkbox aktif, gudang ikut berubah
    public function updatedAddress($value)
    {
        if ($this->useOfficeAsWarehouse) {
            $this->warehouseAddress = $value;
        }
    }
    
    // ------------------------------------------------

    #[On('open-create-modal')] 
    public function openCreateModal()
    {
        $this->reset(); 
        $this->isEditing = false;
        $this->isOpen = true;
        $this->code = Customer::generateCustomerCode();
    }

    #[On('edit-customer')] 
    public function editCustomer($id)
    {
        $this->reset();
        $this->isEditing = true;
        $this->isOpen = true;
        $this->customerId = $id;

        $customer = Customer::with('user')->findOrFail($id);
        
        $this->code = $customer->customer_code; 
        $this->companyName = $customer->company_name;
        $this->phone = $customer->phone;
        $this->city = $customer->city;
        $this->address = $customer->address;
        
        $this->npwp = $customer->npwp;
        $this->taxAddress = $customer->tax_address;
        $this->warehouseAddress = $customer->warehouse_address;

        // Cek apakah alamat gudang sama dengan kantor untuk set checkbox
        if ($this->address && $this->address === $this->warehouseAddress) {
            $this->useOfficeAsWarehouse = true;
        }

        if ($customer->user) {
            $this->userId = $customer->user_id;
            $this->name = $customer->user->name;
            $this->email = $customer->user->email;
        }
    }

    public function closeModal()
    {
        $this->isOpen = false;
        $this->resetValidation();
    }

    public function store()
    {
        $rules = [
            'companyName' => 'required|string|max:255',
            'name'        => 'required|string',
            'npwp'        => 'nullable|string',
            'taxAddress'  => 'nullable|string',
            'address'     => 'nullable|string',
        ];

        if ($this->isEditing) {
            $rules['email'] = ['required', 'email', Rule::unique('users', 'email')->ignore($this->userId)];
            $rules['password'] = 'nullable|min:6';
        } else {
            $rules['email'] = 'required|email|unique:users,email';
            $rules['password'] = 'required|min:6';
        }

        $this->validate($rules);

        if ($this->isEditing) {
            // Update User
            $user = User::find($this->userId);
            if ($user) {
                $userData = ['name' => $this->name, 'email' => $this->email];
                if (!empty($this->password)) {
                    $userData['password'] = Hash::make($this->password);
                }
                $user->update($userData);
            }

            // Update Customer
            $customer = Customer::find($this->customerId);
            $customer->update([
                'company_name'      => $this->companyName,
                'phone'             => $this->phone,
                'city'              => $this->city,
                'address'           => $this->address,     
                'npwp'              => $this->npwp,        
                'tax_address'       => $this->taxAddress,
                'warehouse_address' => $this->warehouseAddress,
            ]);

            $message = 'Data customer berhasil diperbarui!';

        } else {
            // Create User
            $user = User::create([
                'name'     => $this->name,
                'email'    => $this->email,
                'password' => Hash::make($this->password),
                'role'     => 'customer', 
            ]);

            // Create Customer
            Customer::create([
                'user_id'           => $user->id,
                'customer_code'     => $this->code,
                'company_name'      => $this->companyName,
                'phone'             => $this->phone,
                'city'              => $this->city,
                'address'           => $this->address,     
                'npwp'              => $this->npwp,        
                'tax_address'       => $this->taxAddress,
                'warehouse_address' => $this->warehouseAddress,
            ]);

            $message = 'Customer baru berhasil dibuat!';
        }

        $this->isOpen = false;
        $this->dispatch('customer-created'); 
        session()->flash('message', $message);
        
        return redirect(request()->header('Referer'));
    }

    public function render()
    {
        return view('livewire.customer.create');
    }
}