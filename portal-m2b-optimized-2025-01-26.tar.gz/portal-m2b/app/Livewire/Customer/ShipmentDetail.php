<?php

namespace App\Livewire\Customer;

use Livewire\Component;
use Livewire\WithFileUploads;
use App\Models\Shipment;
use App\Models\Document;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;

class ShipmentDetail extends Component
{
    use WithFileUploads;

    public $shipment;
    
    // Variabel Form Upload
    public $file_upload;
    public $doc_type = '';
    public $custom_note = '';

    // Modal Preview Properties (BARU - adopsi dari admin)
    public $showDocPreview = false;
    public $previewDoc = null;
    public $allPublicDocs;
    public $currentDocIndex = 0;

    public function mount($id)
    {
        // LOGIC KEAMANAN PINTAR:
        // 1. Ambil data shipment beserta dokumennya
        $query = Shipment::with(['customer','statuses','documents'])->where('id', $id);

        // 2. Jika yang akses adalah CUSTOMER, paksa filter hanya miliknya
        if (Auth::user()->role === 'customer') {
            $query->where('customer_id', Auth::user()->customer->id);
        }
        
        // 3. Jika ADMIN, loloskan saja (Bisa lihat semua shipment)

        $this->shipment = $query->firstOrFail();
    }

    // === METHOD PREVIEW DOCUMENT (BARU - adopsi dari admin) ===
    public function viewDocument($docId)
    {
        $this->previewDoc = Document::find($docId);
        $this->allPublicDocs = $this->shipment->documents()->where('is_internal', false)->get();
        $this->currentDocIndex = $this->allPublicDocs->search(function($doc) use ($docId) {
            return $doc->id == $docId;
        });
        $this->showDocPreview = true;
    }

    public function nextDocument()
    {
        if ($this->currentDocIndex < $this->allPublicDocs->count() - 1) {
            $this->currentDocIndex++;
            $this->previewDoc = $this->allPublicDocs[$this->currentDocIndex];
        }
    }

    public function previousDocument()
    {
        if ($this->currentDocIndex > 0) {
            $this->currentDocIndex--;
            $this->previewDoc = $this->allPublicDocs[$this->currentDocIndex];
        }
    }

    public function closeDocPreview()
    {
        $this->showDocPreview = false;
        $this->previewDoc = null;
    }
    // === END METHOD PREVIEW ===

    public function uploadDoc()
    {
        $this->validate([
            'file_upload' => 'required|file|mimes:pdf,jpg,jpeg,png,xls,xlsx,doc,docx|max:5120',
            'doc_type' => 'required|string']);

        $ext = $this->file_upload->getClientOriginalExtension();
        $cleanRef = str_replace(['/', '\\'], '-', $this->shipment->awb_number);
        $filename = strtoupper(str_replace(' ', '_', $this->doc_type)) . '_' . $cleanRef . '_' . time() . '.' . $ext;
        
        $path = $this->file_upload->storeAs('documents/customer_uploads', $filename, 'public');

        Document::create([
            'shipment_id' => $this->shipment->id,
            'document_type' => 'customer_upload',
            'filename' => $filename,
            'file_path' => $path,
            'description' => $this->doc_type . ($this->custom_note ? ' - ' . $this->custom_note : ''),
            'is_internal' => false,
            'uploaded_by' => Auth::id(),
            'file_size' => $this->file_upload->getSize(),
            'mime_type' => $this->file_upload->getMimeType(),
            'uploaded_at' => now()]);

        $this->reset(['file_upload', 'doc_type', 'custom_note']);
        $this->shipment->refresh(); 
        
        session()->flash('message', 'Dokumen berhasil diunggah.');
    }

    public function render()
    {
        // DETEKSI LAYOUT OTOMATIS
        // Jika Admin yang buka -> Pakai Layout Admin
        // Jika Customer yang buka -> Pakai Layout Customer
        $layout = Auth::user()->role === 'admin' || Auth::user()->role === 'manager' 
            ? 'layouts.admin' 
            : 'layouts.customer';

        return view('livewire.customer.shipment-detail')->layout($layout);
    }
}
