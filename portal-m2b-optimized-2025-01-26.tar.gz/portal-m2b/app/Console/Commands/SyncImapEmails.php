<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Webklex\PHPIMAP\ClientManager;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class SyncImapEmails extends Command
{
    protected $signature = 'imap:sync {account?} {--limit=50}';
    protected $description = 'Sync emails from IMAP servers to database';

    public function handle()
    {
        $account = $this->argument('account') ?? 'all';
        $limit = $this->option('limit');
        
        $accounts = $account === 'all' 
            ? ['sales', 'import', 'export'] 
            : [$account];

        foreach ($accounts as $acc) {
            $this->info("Syncing {$acc} account...");
            $this->syncAccount($acc, $limit);
        }

        $this->info('✅ Sync completed!');
    }

    private function syncAccount($accountName, $limit)
    {
        try {
            $cm = new ClientManager();
            
            // Get account config
            $config = config("imap.accounts.{$accountName}");
            
            if (!$config) {
                $this->error("Account {$accountName} not configured!");
                return;
            }
            
            // Create client with EXPLICIT config
            $client = $cm->make([
                'host' => $config['host'],
                'port' => $config['port'],
                'encryption' => $config['encryption'],
                'validate_cert' => $config['validate_cert'],
                'username' => $config['username'],
                'password' => $config['password'],
                'protocol' => $config['protocol'],
                'timeout' => $config['timeout'] ?? 30,
            ]);
            
            $client->connect();

            $folder = $client->getFolder('INBOX');
            $messages = $folder->messages()->all()->limit($limit)->get();

            $this->info("  Found {$messages->count()} messages");

            foreach ($messages as $message) {
                try {
                    $messageId = $message->getMessageId();
                    
                    // Check if email already exists
                    $exists = DB::table('emails')->where('message_id', $messageId)->exists();
                    
                    if ($exists) {
                        continue;
                    }

                    // Get from address - handle Attribute object
                    $from = $message->getFrom();
                    $fromName = '';
                    $fromEmail = '';
                    
                    if ($from) {
                        // Check if it's an array or Attribute
                        if (is_array($from) && isset($from[0])) {
                            $fromName = $from[0]->personal ?? '';
                            $fromEmail = $from[0]->mail ?? '';
                        } elseif (is_object($from)) {
                            // Handle Attribute object
                            $fromArray = $from->toArray();
                            if (!empty($fromArray)) {
                                $first = $fromArray[0] ?? null;
                                if ($first) {
                                    $fromName = $first->personal ?? '';
                                    $fromEmail = $first->mail ?? '';
                                }
                            }
                        }
                    }
                    
                    // Get to address
                    $to = $message->getTo();
                    $toEmail = '';
                    
                    if ($to) {
                        if (is_array($to) && isset($to[0])) {
                            $toEmail = $to[0]->mail ?? '';
                        } elseif (is_object($to)) {
                            $toArray = $to->toArray();
                            if (!empty($toArray)) {
                                $first = $toArray[0] ?? null;
                                if ($first) {
                                    $toEmail = $first->mail ?? '';
                                }
                            }
                        }
                    }

                    // Insert email
                    $emailId = DB::table('emails')->insertGetId([
                        'mailbox' => $accountName,
                        'message_id' => $messageId,
                        'subject' => $message->getSubject() ?? '(No Subject)',
                        'from_name' => $fromName,
                        'from_email' => $fromEmail,
                        'to_email' => $toEmail,
                        'body' => $message->getHTMLBody(),
                        'email_date' => Carbon::parse($message->getDate()),
                        'has_attachments' => $message->hasAttachments(),
                        'is_read' => $message->getFlags()->has('seen'),
                        'created_at' => now(),
                        'updated_at' => now(),
                    ]);

                    // Insert attachments
                    if ($message->hasAttachments()) {
                        $attachments = $message->getAttachments();
                        
                        foreach ($attachments as $attachment) {
                            DB::table('email_attachments')->insert([
                                'email_id' => $emailId,
                                'filename' => $attachment->getName(),
                                'content' => base64_encode($attachment->getContent()),
                                'mime_type' => $attachment->getMimeType(),
                                'size' => $attachment->getSize(),
                                'created_at' => now(),
                            ]);
                        }
                    }

                    $this->info("  ✓ {$message->getSubject()}");
                    
                } catch (\Exception $e) {
                    $this->warn("  ⚠ Skipped 1 message: " . $e->getMessage());
                    continue;
                }
            }

            $client->disconnect();

        } catch (\Exception $e) {
            $this->error("  ❌ Failed: " . $e->getMessage());
        }
    }
}
